const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');



const router = express.Router();

// Define the register route
router.post('/admin', require('./../controller/admin/admin.routes'));
router.post('/user', require('./../controller/user/user.routes'));

module.exports = router;